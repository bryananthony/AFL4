//
//  DormRow.swift
//  AFL3Archdorm
//
//  Created by SIFT - Telkom DBT Air 7 on 06/06/22.
//

import SwiftUI

struct Dorm: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Dorm_Previews: PreviewProvider {
    static var previews: some View {
        Dorm()
    }
}
