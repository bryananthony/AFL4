//
//  ContentView.swift
//  AFL3Archdorm
//
//  Created by SIFT - Telkom DBT Air 7 on 06/06/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView{
            ImageView()
            VStack(alignment: .leading){
                HStack{
                    VStack (alignment: .leading){
                        Text("Denver Apartment")
                            .font(.title)
                            .fontWeight(.black)
                        Text("Osaka Prefecture, fuushi Street 30")
                    }
                    Spacer()
                }
                .padding()
                
                Divider()
                
                VStack(alignment: .leading){
                    HStack{
                        Text("Features")
                            .font(.title2)
                            .fontWeight(.bold)
                        Spacer()
                        
                    }
                    VStack(alignment: .leading){
                        Text("- Free Photo")
                        Text("- Free Pray")
                        Text("- Free Food ‡ Drink")
                    }
                    .padding(.leading)
                }
                .padding()
                
                VStack(alignment: .leading){
                    HStack{
                        Text("Details")
                            .font(.title2)
                            .fontWeight(.bold)
                        Spacer()
                        
                    }
                    VStack(alignment: .leading){
                        Text("Sebuah tempat perbatasan alam roh dan alam hidup, tempat yang cocok untuk melakukan meditasi & refleksi")
                    }
                    .padding(.leading)
                }
                .padding()
                
                VStack(alignment: .leading){
                    HStack{
                        Text("Dorm Type")
                            .font(.title2)
                            .fontWeight(.bold)
                        Spacer()
                        
                    }
                    HStack(){
                        Text("Shrine")
                        
                    }
                    .padding(.leading)
                }
                .padding()
                
            }
        }
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewDevice("iPhone 13 Pro Max")
    }
}
