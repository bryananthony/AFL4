//
//  main.swift
//  AFL3Archdorm
//
//  Created by SIFT - Telkom DBT Air 7 on 06/06/22.
//


import SwiftUI

struct ArchDormApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}

