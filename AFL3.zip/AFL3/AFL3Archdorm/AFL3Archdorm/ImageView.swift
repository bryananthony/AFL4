//
//  Image.swift
//  AFL3Archdorm
//
//  Created by SIFT - Telkom DBT Air 7 on 06/06/22.
//

import SwiftUI

struct ImageView: View {
    var body: some View {
        Image("torigate")
            .frame(width: 300)
    }
}

struct ImageView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ImageView()
    }
}
}
